# 数据格式

RenFace数据集的最基本文件为h5格式的SMC文件，名为 `{actorID}_{actionType}{actionID}_{sub_actionID}.smc`.
每一个SMC文件打包了 60 组同步多视角的图片帧、音频 (如果说话)、标定参数、标注内容。
`actionType` 包括 `s` （指说话）, `h` （发型） `e`（表情）。
`actionID` 为采集片段的id。
`sub_actionID`为每个采集片段的细分(如有)；其中假发采集部分 `sub_actionID`组成名为 `{假发ID}{颜色}`。

SMC文件内部的顶层组织如下：

<!-- <div style="background-color:#D6FFD6; text-align:center; vertical-align: middle; padding:40px 0; margin-top:30px">
{<a href="/blog">VIEW THE BLOG</a>}
</div> -->

```json
{
    "attrs"				   : 演员ID的属性, 
    "Images"                               : 多视角图片帧和音频, 
    "Calibration"                          : 相机标定, 
    "Annotation"                           : 关键点标注和拟合参数, 
}
```

## 1. 基础属性

 `attrs` 组存储动作的基本属性, 包括演员和相机的属性。

```json
{
    ".attrs"{
        "age"                              : int,
        "gender"                           : str ["male", "female"],
        "color"                            : str ["yellow", "white", "black", "brown"],
        "height"                           : float,
        "weight"                           : float,
    }
    "Camera.attrs"{
        "num_device"                       : int,
        "num_frame"                        : int,
        "resolution"                       : int (height, width),
    }
}
```

## 2. 视频

`Videos` 组包含了所有的图片和音频。每一个图片帧可以通过 `cameraID`, `frameID` 以及图片格式 [`color`, `mask`, `audio`] 索引。

```json
 {
    "cameraID"{
        "color"{
            "frameID"                       : uint8 (2048, 2448, 3)
            ...
        }, 
        "mask"{
	    "frameID"		            : uint8 (2048, 2448, 3), 使用 BackgroundMattingV2
           ...
        },
    }
    "audio": ...	                    : uint8, 如果动作包含说话
}
```

## 3. 标定

`Calibrations` 组提供所有相机的标定参数，包含相机的内参、外参、畸变参数，通过 `cameraID`索引。

```json
{
    "cameraID"{   
        "K"                                 : double (3,3) 内参矩阵,
        "D"                                 : double (5,) 畸变系数, 
        "RT"                                : double (4,4) 相机到世界坐标系变换
    }
}
```

## 4. 标注

`Annotations`组提供了RenFace数据集的标注数据。具体地，`Keypoint2d`存储正面相机视角的2D关键点的检测结果(view 18~32)；`Keypoint3d`包含整体3D关键点的位置。

```json
{
    "cameraID"{
        "Keypoint2d"{  
            "frameID"                       : double (frame_num,106,2)
            ...
            }
    }
    "Keypoints3d"{  
            "frameID"                       : double (frame_num,73,3)
            ...
        }
}
```

## 5. FLAME
`Annotations`组提供了RenFace数据集的标注数据。具体地，`FLAME`存储每一帧拟合的FLAME 人脸参数模型的相关参数。(只有表情部分有)
```json
{
    "FLAME"{
        "frameID"{  
            "global_pose"                   : double (3,)
            "neck_pose"                     : double (3,)
            "jaw_pose"                      : double (3,)
            "left_eye_pose"                 : double (3,)
            "right_eye_pose"                : double (3,)
            "trans"                         : double (3,)
            "shape"                         : double (100,)
            "exp"                           : double (50,)
            "verts"                         : double (5023,3)
            "albedos"                       : double (3,256,256)
            }
    }
}
```

## 6. 纹理贴图
`Annotations`组提供了RenFace数据集的标注数据。具体地，`UV_texture`存储每一帧拟合的纹理贴图。(只有表情部分有)
```json
{
    "UV_texture"{
        "frameID"                           : uint8 (256, 256, 3)
    }
}
```

## 7. 稠密重建
`Annotations`组提供了RenFace数据集的标注数据。具体地，`Scan`存储单帧的稠密重建mesh结果。(只有表情部分有)
```json
{
    "Scan"{
        "vertex"                            : double (n, 3), n: number of vertices
        "vertex_indices"                    : int    (m, 3), m: number of index
    }
}
```




# 数据接口

我们提供了一个标准数据接口[renface_reader.py](./renbody_reader.py)用以读取SMC文件内包含的所有数据，包含基础属性、图片、标定以及标注。下面是一个最小的范例：

```python
>> from smc_reader import SMCReader
>> import numpy as np

>> reader = SMCReader('smc_file')
>> Camera_id = "01"
>> Frame_id = 0

>> audio = reader.get_audio()          			# Load audio
>> image = reader.get_img(Camera_id, 'color', Frame_id)          # Load image for the specified camera and frame
>> print(image.shape)
(2048, 2448, 3)
>> mask = reader.get_img(Camera_id, 'mask', Frame_id)            # Load mask for the specified camera and frame
>> print(mask.shape)
(2048, 2448)

>> calibration  = reader.get_Calibration(Camera_id) 	# Load camera parameters for the specified camera. 
>> print(calibration['K'].shape, calibration['D'].shape, calibration['RT'].shape)
(3, 3)  (5, )  (4, 4)

>> lmk2d = reader.get_Keypoints2d(Camera_id, Frame_id)    # Load landmark 2d for the specified frame. (face landmarks 106)
>> print(lmk2d.shape)
(106, 2)

>> lmk3d = reader.get_Keypoints3d(Frame_id)    # Load landmark 3d for the specified frame. (33 contour points not included)
>> print(lmk3d.shape)
(73, 3)

>> flame = reader.get_FLAME(Frame_id)         # Load FLAME parameters for the specified frame.
>> print(flame.keys())
['albedos', 'cam', 'exp', 'global_pose', 'jaw_pose', 'left_eye_pose', 'lit', 'neck_pose', 'right_eye_pose', 'shape', 'tex', 'trans', 'verts']

>> uv = reader.get_uv(Frame_id)         # Load uv texture map for the specified frame.
>> print(uv.keys())
(256, 256, 3)

>> scan = reader.get_scanmesh(Frame_id)         # Load scan mesh for the expression part.
>> print(scan.keys())
['vertex', 'vertex_indices']
```
