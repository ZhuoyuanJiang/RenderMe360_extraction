# Data Format

The foundemental element of RenFace dataset is a h5 based SMC file, named with `{actorID}_{actionType}{actionID}_{sub_actionID}.smc`.
Each SMC file packs 60 sets of synchronous multi-view image frames, audios (if talking), calibrations, and annotations.
The `actionType` includes `s` for speech, `h` for hair style and `e` for expression.
The `actionID` is the collection id.
`sub_actionID` is the subdivision of each collection segment (if any); where the wig collection part `sub_actionID` is composed as `{wigID}{color}`.

The top level of SMC file is organized as

<!-- <div style="background-color:#D6FFD6; text-align:center; vertical-align: middle; padding:40px 0; margin-top:30px">
{<a href="/blog">VIEW THE BLOG</a>}
</div> -->

```json
{
    "attrs"				   : atrributes of actor ID, 
    "Images"                               : multi-view image frames and audios, 
    "Calibration"                          : calibration of cameras, 
    "Annotation"                           : keypoints annotation and fitting parameters, 
}
```

## 1. Basic Attributes

The `attrs` group stores basic attribute information of the ID, including attributes of the actor and the camera.

```json
{
    ".attrs"{
        "age"                              : int,
        "gender"                           : str ["male", "female"],
        "color"                            : str ["yellow", "white", "black", "brown"],
        "height"                           : float,
        "weight"                           : float,
    }
    "Camera.attrs"{
        "num_device"                       : int,
        "num_frame"                        : int,
        "resolution"                       : int (height, width),
    }
}
```

## 2. Videos

The `Videos` group contains all captured images and audios. Each image frame can be indexed by its `cameraID`, `frameID` and its type [`color`, `mask`, `audio`].

```json
 {
    "cameraID"{
        "color"{
            "frameID"                       : uint8 (2048, 2448, 3)
            ...
        }, 
        "mask"{
	    "frameID"		            : uint8 (2048, 2448, 3), with BackgroundMattingV2
           ...
        },
    }
    "audio": ...	                    : uint8, exists if the action contains talking
}
```

## 3. Calibrations

The `Calibrations` group gives the calibration coeffient of all cameras including intrinsic, extrinisc and distortions, indexed by `cameraID`.

```json
{
    "cameraID"{   
        "K"                                 : double (3,3) intrinsic matrix,
        "D"                                 : double (5,) distortion coeffient, 
        "RT"                                : double (4,4) maps point from camera to world
    }
}
```

## 4. Annotations

The `Annotations` group provides the annotation of RenFace dataset labelled computed by the state-of-art methods. Specifically, `Keypoint2d` stores the detected 2D keypoints from all camera views. `Keypoint3d` provides 3D keypoints.

```json
{
    "cameraID"{
        "Keypoint2d"{  
            "frameID"                       : double (frame_num,106,2)
            ...
            }
    }
    "Keypoints3d"{  
            "frameID"                       : double (frame_num,73,3)
            ...
        }
}
```

## 5. FLAME
The `Annotations` group provides the annotation of RenFace dataset labelled computed by the state-of-art methods. Specifically, `FLAME` stores the FLAME fitting parameters from each frame. (only in expression part)
```json
{
    "FLAME"{
        "frameID"{  
            "global_pose"                   : double (3,)
            "neck_pose"                     : double (3,)
            "jaw_pose"                      : double (3,)
            "left_eye_pose"                 : double (3,)
            "right_eye_pose"                : double (3,)
            "trans"                         : double (3,)
            "shape"                         : double (100,)
            "exp"                           : double (50,)
            "verts"                         : double (5023,3)
            "albedos"                       : double (3,256,256)
            }
    }
}
```

## 6. uv texture
The `Annotations` group provides the annotation of RenFace dataset labelled computed by the state-of-art methods. Specifically, `UV_texture` stores the uv texture map from each frame. (only in expression part)
```json
{
    "UV_texture"{
        "frameID"                           : uint8 (256, 256, 3)
    }
}
```

## 7. scan mesh
The `Annotations` group provides the annotation of RenFace dataset labelled computed by the state-of-art methods. Specifically, `Scan` stores the scan mesh data. (only in expression part)
```json
{
    "Scan"{
        "vertex"                            : double (n, 3), n: number of vertices
        "vertex_indices"                    : int    (m, 3), m: number of index
    }
}
```

# Data Interface

We provide a standard data interface [renface_reader.py](./smc_reader.py) to fetch each data including all attributes, images, calibrations and annotations. Here is a tiny example.

```python
>> from smc_reader import SMCReader
>> import numpy as np

>> reader = SMCReader('smc_file')
>> Camera_id = "01"
>> Frame_id = 0

>> audio = reader.get_audio()          			# Load audio
>> image = reader.get_img(Camera_id, 'color', Frame_id)          # Load image for the specified camera and frame
>> print(image.shape)
(2048, 2448, 3)
>> mask = reader.get_img(Camera_id, 'mask', Frame_id)            # Load mask for the specified camera and frame
>> print(mask.shape)
(2048, 2448)

>> calibration  = reader.get_Calibration(Camera_id) 	# Load camera parameters for the specified camera. 
>> print(calibration['K'].shape, calibration['D'].shape, calibration['RT'].shape)
(3, 3)  (5, )  (4, 4)

>> lmk2d = reader.get_Keypoints2d(Camera_id, Frame_id)    # Load landmark 2d for the specified frame. (face landmarks 106)
>> print(lmk2d.shape)
(106, 2)

>> lmk3d = reader.get_Keypoints3d(Frame_id)    # Load landmark 3d for the specified frame. (33 contour points not included)
>> print(lmk3d.shape)
(73, 3)

>> flame = reader.get_FLAME(Frame_id)         # Load FLAME parameters for the specified frame.
>> print(flame.keys())
['albedos', 'cam', 'exp', 'global_pose', 'jaw_pose', 'left_eye_pose', 'lit', 'neck_pose', 'right_eye_pose', 'shape', 'tex', 'trans', 'verts']

>> uv = reader.get_uv(Frame_id)         # Load uv texture map for the specified frame.
>> print(uv.keys())
(256, 256, 3)

>> scan = reader.get_scanmesh(Frame_id)         # Load scan mesh for the expression part.
>> print(scan.keys())
['vertex', 'vertex_indices']
```
